const { ipcRenderer } = require('electron')

console.log(navigator.appVersion);

ipcRenderer.on('SET_SOURCE', async (event, sourceId) => {
    // console.log('sourceId:',sourceId);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: sourceId,
          }
        }
      })
      gotLocalMediaStream(stream)
    } catch (e) {
      handleError(e)
    }
  })

  function gotLocalMediaStream(mediaStream) {
    const localStream = mediaStream;
    const localVideo = document.querySelector("video");
    if ("srcObject" in localVideo) {
      localVideo.srcObject = localStream;
    } else {
      localVideo.src = window.URL.createObjectURL(localStream);
    }
  }
  
  function handleError (e) {
    console.log(e)
  }  