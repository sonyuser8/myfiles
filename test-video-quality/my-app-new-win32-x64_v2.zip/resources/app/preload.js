const { ipcRenderer } = require('electron')

console.log(navigator.appVersion);

ipcRenderer.on('SET_SOURCE', async (event, sourceId) => {
    console.log('sourceId:',sourceId);
    try {
      const videoConstraint = {
        audio: false,
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: sourceId,
            minWidth: window.screen.width * window.devicePixelRatio,
            maxWidth: window.screen.width * window.devicePixelRatio,
            minHeight: window.screen.height * window.devicePixelRatio,
            maxHeight: window.screen.height * window.devicePixelRatio
          }
        }}
      console.log('videoConstraint:', videoConstraint)
      const stream = await navigator.mediaDevices.getUserMedia(videoConstraint)
      gotLocalMediaStream(stream)
    } catch (e) {
      handleError(e)
    }
  })

  function gotLocalMediaStream(mediaStream) {
    const localStream = mediaStream;
    const localVideo = document.querySelector("video");
    if ("srcObject" in localVideo) {
      localVideo.srcObject = localStream;
    } else {
      localVideo.src = window.URL.createObjectURL(localStream);
    }
  }
  
  function handleError (e) {
    console.log(e)
  }  